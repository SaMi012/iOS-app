# Weatherpp
Simple app for weather estimate.
If you want to learn how to parse json in swift 3, this project for you.
