//
//  WeatherViewController.swift
//  ToolBox
//
//  Created by kuet on 29/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit

class WeatherViewController: UIViewController {

    @IBOutlet weak var cityName: UITextField!
    
    @IBOutlet weak var weatherDetail: UILabel!
    
    @IBAction func Calculate(_ sender: Any) {
        
        let cityName = self.cityName.text
        
        if let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=" + cityName! + ",uk&APPID=4e65a399aab1bbd77e8bb62ea21e9928")
        {
            
            let task = URLSession.shared.dataTask(with: url){data,response,error in
                
                if(error != nil)
                {
                    print(error!)
                }
                    
                else
                {
                    if let urlContent = data {
                        
                        do
                        {
                            let json = try JSONSerialization.jsonObject(with: urlContent, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                            
                            if let weatherDetail = json["main"] as? NSDictionary
                            {
                                let temp = weatherDetail["temp"] as? Double
                               
                                let tempCelcius = temp! - 273.15
                                
                                print( temp! )
                        
                                DispatchQueue.main.async(execute: {
                                    self.weatherDetail.text = String(describing: tempCelcius)
                                    
                                })
                            }
                        }
                            
                        catch
                        {
                            print("Failed")
                        }
                    }
                }
            }
            
            task.resume()
            
        }
        else
        {
            print("Incorrect city")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    
    


}
