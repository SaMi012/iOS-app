//
//  SignUpVC.swift
//  ToolBox
//
//  Created by kuet on 22/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit

class SignUpVC: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
