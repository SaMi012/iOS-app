//
//  ToDoViewController.swift
//  ToolBox
//
//  Created by kuet on 22/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase
import FirebaseAuth
//var list = ["Buy milk","walk 2 miles","Call someone","Travel"]

var dic:[String:String] = [:]
var ref:DatabaseReference!
var databaseHandle:DatabaseHandle!

class ToDoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var postData = [String]()
    
    @IBOutlet weak var addtext: UITextField!
    
    @IBAction func onTappedAdd(_ sender: Any) {
        
        if(addtext.text != ""){
            
            guard let id = Auth.auth().currentUser?.uid else {return}
            ref.child("user_todo").child(id).childByAutoId().setValue(addtext.text)
            addtext.text=""
            self.myTableView.reloadData()
            
        }
        
    }
    @IBOutlet weak var myTableView: UITableView!
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return (postData.count)
        
    }
    
    
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.text = postData [indexPath.row]
        return (cell)
        
        
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            let str = postData[indexPath.row]
            postData.remove(at: indexPath.row)
            guard let id = Auth.auth().currentUser?.uid else {return}
            //ref.child("user_todo").child(id).setValue(postData)

            let k = dic[str]
            ref.child("user_todo").child(id).child(k!).removeValue()
            myTableView.reloadData()
        }
        
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        myTableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.myTableView.reloadData()
        ref=Database.database().reference()
        guard let id = Auth.auth().currentUser?.uid else{return}
        databaseHandle = ref?.child("user_todo").child(id).observe(.childAdded, with: { (snapshot) in
            //execute when a child is added...
            //take the value from the snapshot...
            let post = snapshot.value as? String
            let ke = snapshot.key
            dic[post!] = ke
            if let actualPost = post {
                self.postData.append(actualPost)
                self.myTableView.reloadData()
            }
            
        })
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    

   
 

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
