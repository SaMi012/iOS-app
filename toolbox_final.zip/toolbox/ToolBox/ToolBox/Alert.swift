//
//  Alert.swift
//  ToolBox
//
//  Created by kuet on 22/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit

class  Alert {
    static func showAlert(_inViewController: UIViewController, title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title:"OK", style: .default, handler: nil)
        alert.addAction(action)
        _inViewController.present(alert, animated: true, completion: nil)
    }
}
