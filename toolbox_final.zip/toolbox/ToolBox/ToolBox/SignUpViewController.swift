//
//  SignUpViewController.swift
//  ToolBox
//
//  Created by kuet on 22/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class SignUpViewController: UIViewController {
    

    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var userNameTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func OnSignUpTapped(_ sender: Any) {
        
        guard let userName = userNameTF.text,
        userName != "",
        let email = emailTF.text,
        email != "",
        let password = passwordTF.text,
        password != ""
            else{
                Alert.showAlert(_inViewController: self, title: "Missing Fields", message: "please fill out all fields")
                return
        }
        
        Auth.auth().createUser(withEmail: email, password: password, completion: { (user, error) in
            if error == nil && user != nil{
 //               Alert.showAlert(_inViewController: self, title: "Sign Up", message: "successfully signed up")
                print("user created")
                
                let chageRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                chageRequest?.displayName = userName
                chageRequest?.commitChanges { error in
                    if error == nil {
                    print("user display name changed")
                    }
                }
                
                self.performSegue(withIdentifier: "SignUpSignInSegue", sender: nil)
                
            }
            else{
                print("Error: \(error!.localizedDescription)")
            }
            
            
            
        })
        
        
        
        
        
    }
    
    

}
