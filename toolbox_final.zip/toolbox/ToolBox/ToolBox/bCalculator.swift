//
//  Bcalculator.swift
//  ToolBox
//
//  Created by kuet on 26/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import Foundation

class actualCalculator {
    var height:Double
    var weight:Double
    
    init (height:Double,weight:Double){
        self.height=height
        self.weight=weight
    }
    
    func bmi()->Double {
        if height>0 && weight>0 {return weight/(height*height)}
        else {
            return 0
        }
    }
}

