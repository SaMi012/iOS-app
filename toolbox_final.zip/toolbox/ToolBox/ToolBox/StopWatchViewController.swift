//
//  StopWatchViewController.swift
//  ToolBox
//
//  Created by kuet on 25/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit

class StopWatchViewController: UIViewController {
    
    var stopWatchTimer=Timer()
    var currentTime=0
    
    @IBOutlet weak var MINUTES: UILabel!
    @IBOutlet weak var SECONDS: UILabel!
    @IBOutlet weak var startbutton: UIButton!
    @IBOutlet weak var stopbutton: UIButton!
    @IBOutlet weak var pausebutton: UIButton!
    
    
    
    
    @IBAction func hasStopButtonPressed(_ sender: Any) {
        startbutton.isHidden=false
        pausebutton.isHidden=true
        stopbutton.isEnabled=false
        currentTime=0
        MINUTES.text="0"
        SECONDS.text="0"
        stopWatchTimer.invalidate()
    }
    
    @IBAction func hasStartBUttonPressed(_ sender: Any) {
        startbutton.isHidden=true
        pausebutton.isHidden=false
        stopbutton.isEnabled=true
        stopWatchTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(StopWatchViewController.updateTime)), userInfo: nil, repeats: true)
    }
    
    @IBAction func hasPauseButtonPressed(_ sender: Any) {
        startbutton.isHidden=false
        pausebutton.isHidden=true
        stopWatchTimer.invalidate()
    }
    @objc func updateTime() {
        currentTime += 1
        MINUTES.text = "\(currentTime / 60 )"
        SECONDS.text = "\(currentTime % 60 )"
        if currentTime == 3600 {
            currentTime = 0
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        pausebutton.isHidden=true
        stopbutton.isEnabled=false

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
