//
//  BMIViewController.swift
//  ToolBox
//
//  Created by kuet on 25/11/18.
//  Copyright © 2018 kuet. All rights reserved.
//

import UIKit

class BMIViewController: UIViewController {

    @IBOutlet weak var heightField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var resultField: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func bmiButton(_ sender: Any) {
        let height=Double(heightField.text!)
        let weight=Double(weightField.text!)
        let bmiObject=actualCalculator(height:height!,weight:weight!)
        //resultField.text=String(bmiObject.bmi())
        let checkValidity=bmiObject.bmi()
        if checkValidity>0 {
            resultField.text=String(checkValidity)
        }
        else {
            resultField.text="Insert valid input"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
